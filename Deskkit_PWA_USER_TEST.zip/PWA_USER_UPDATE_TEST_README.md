# PWA user update test v4

This test makes one harmless visible change: a green "PWA UPDATE TEST v4" badge.

PWA registration uses vite-plugin-pwa's built-in registration; no direct
workbox-window dependency is added.

Deploy to the SAME Netlify site. Open the already-installed DeskKit PWA.
Close/reopen it and refresh if needed. If the green badge appears in the
already-installed app, the update reached the existing PWA.

After confirming, remove the badge from index.html and app-version.txt.
