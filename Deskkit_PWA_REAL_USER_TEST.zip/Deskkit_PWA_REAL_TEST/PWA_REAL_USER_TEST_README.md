# DeskKit real-user PWA update test

This test version uses manual navigator.serviceWorker registration.
It sets injectRegister: false in vite-plugin-pwa so Vite 8/Rolldown does not bundle workbox-window.

A green PWA UPDATE TEST v5 badge is visible in the web app and installed PWA.
The page checks the service worker every 30 seconds during this test.

IMPORTANT: deploy this to the SAME production Netlify site. Do not use a deploy-preview URL.

Test:
1. Deploy to the same production site.
2. Open the production URL and verify the green v5 badge appears.
3. Open the already-installed DeskKit PWA from that same production origin.
4. Close/reopen it and wait up to 30 seconds.
5. The v5 badge should appear.
