import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

// Manual PWA registration avoids workbox-window and works with Vite 8/Rolldown.
if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    const hadController = Boolean(navigator.serviceWorker.controller)

    try {
      const registration = await navigator.serviceWorker.register('/sw.js', { scope: '/' })

      // Check for a new Netlify deployment immediately and every 30 seconds for testing.
      await registration.update()
      window.setInterval(() => registration.update(), 30_000)

      registration.addEventListener('updatefound', () => {
        const worker = registration.installing
        if (!worker) return

        worker.addEventListener('statechange', () => {
          if (worker.state === 'installed' && navigator.serviceWorker.controller) {
            worker.postMessage({ type: 'SKIP_WAITING' })
          }
        })
      })

      // If an already-installed PWA gets a new worker, reload once to show it.
      if (hadController) {
        navigator.serviceWorker.addEventListener('controllerchange', () => {
          window.location.reload()
        }, { once: true })
      }
    } catch (error) {
      console.error('DeskKit PWA service worker registration failed:', error)
    }
  })
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
