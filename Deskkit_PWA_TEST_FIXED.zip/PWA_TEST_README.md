# DeskKit PWA TEST v2 - FIXED

This build contains a visible green `PWA UPDATE TEST v2` marker.

IMPORTANT:
- Deploy this ZIP to the SAME Netlify site.
- Do not create a new Netlify site.
- Do not delete the existing site.
- The service worker checks for a new deployment every 30 seconds for this test.
- After deploying, close/reopen the installed PWA and wait up to about 30 seconds.

If the green marker appears in the installed PWA, the update path is working.

After testing, remove the marker and change the check interval back to 1 hour.
