import { registerSW } from 'virtual:pwa-register'

export const updateSW = registerSW({
  immediate: true,

  onNeedRefresh() {
    console.log('DeskKit: a new version is available.')
  },

  onOfflineReady() {
    console.log('DeskKit: offline version is ready.')
  },

  onRegisteredSW(_swUrl, registration) {
    if (!registration) return

    // Check for a new deployment periodically.
    window.setInterval(() => {
      registration.update()
    }, 60 * 60 * 1000)
  },

  onRegisterError(error) {
    console.error('DeskKit service worker registration error:', error)
  },
})
