import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'


// Native PWA registration: avoids workbox-window and lets existing installed
// PWAs pick up new Netlify deployments automatically.
if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    try {
      const hadController = Boolean(navigator.serviceWorker.controller)
      const registration = await navigator.serviceWorker.register('/sw.js', { scope: '/' })

      // Force a service-worker update check when the app starts.
      await registration.update()

      // Extra checks during this test. Change to 60 * 60 * 1000 for production.
      window.setInterval(() => {
        registration.update().catch(() => {})
      }, 30 * 1000)

      if (hadController) {
        navigator.serviceWorker.addEventListener('controllerchange', () => {
          window.location.reload()
        }, { once: true })
      }

      console.log('[DeskKit PWA] service worker registered:', registration.scope)
    } catch (error) {
      console.error('[DeskKit PWA] registration failed:', error)
    }
  })
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
