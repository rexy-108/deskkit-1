# DeskKit PWA UPDATE TEST v6

This is a clean test build based on the original project.

Changes only for testing:
- Browser-native service worker registration (no workbox-window import).
- vite-plugin-pwa still generates `dist/sw.js`.
- Service worker checks for updates every 30 seconds during this test.
- Existing installed PWAs reload when a new service worker takes control.
- Netlify sends no-cache headers for `/index.html` and `/sw.js`.
- Visible marker: `PWA UPDATE TEST v6`.

Deploy to the SAME Netlify production site. Do not uninstall the existing PWA.
First verify the normal website shows the green v6 badge. Then close/reopen the already-installed PWA and wait up to about 30 seconds.
